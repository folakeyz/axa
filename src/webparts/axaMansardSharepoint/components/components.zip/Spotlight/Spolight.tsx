import * as React from 'react';
import style from '../axa.module.scss';

const Spolight = () => {
return(
<div  className={style.spolights}>
<h3>NEW STAFF/FEATURED STAFF</h3>
<div  className={style.spolight}>

</div>

</div>
);
}
export default Spolight;