import * as React from 'react';
import { Component } from 'react';
import * as ReactDOM from 'react-dom';
// import ReactDOM from 'react-dom';
import "react-responsive-carousel/lib/styles/carousel.min.css"; // requires a loader
import { Carousel } from 'react-responsive-carousel';


class DemoCarousel extends Component {
    render() {
        return (
            <Carousel>
                <div>
                    <img src="https://www.axamansard.com/images/banners/EduPlan-Plus-Website-Banner.jpg" />
                </div>
                <div>
                  <img src="https://www.axamansard.com//images/banners/cover-motor.jpg"/>
                </div>
                <div>
                <img src="https://www.axamansard.com/images/banners/cover-health.jpg"/>
                </div>
            </Carousel>
        );
    };
};
 export default DemoCarousel;
