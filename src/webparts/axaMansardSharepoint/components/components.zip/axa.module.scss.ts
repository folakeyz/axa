/* tslint:disable */
require("./axa.module.css");
const styles = {
  axaMansardSharepoint: 'axaMansardSharepoint_9b8e5c0a',
  axaaxaMansardSharepoint: 'axaaxaMansardSharepoint_9b8e5c0a',
  alertBtns: 'alertBtns_9b8e5c0a',
  alertMarquee: 'alertMarquee_9b8e5c0a',
  axaMansardLeft: 'axaMansardLeft_9b8e5c0a',
  axaMansardRight: 'axaMansardRight_9b8e5c0a',
  timer: 'timer_9b8e5c0a',
  timerText: 'timerText_9b8e5c0a',
  timerValue: 'timerValue_9b8e5c0a',
  alert: 'alert_9b8e5c0a',
  alertNews: 'alertNews_9b8e5c0a',
  eachSlide: 'eachSlide_9b8e5c0a',
  links: 'links_9b8e5c0a',
  avatar: 'avatar_9b8e5c0a',
  avatarName: 'avatarName_9b8e5c0a',
  cardOutline: 'cardOutline_9b8e5c0a',
  ratings: 'ratings_9b8e5c0a',
  ratingsOutline: 'ratingsOutline_9b8e5c0a',
  docCard: 'docCard_9b8e5c0a',
  docCardLeft: 'docCardLeft_9b8e5c0a',
  docCardRight: 'docCardRight_9b8e5c0a',
  spolights: 'spolights_9b8e5c0a',
  spolight: 'spolight_9b8e5c0a'
};

export default styles;
/* tslint:enable */